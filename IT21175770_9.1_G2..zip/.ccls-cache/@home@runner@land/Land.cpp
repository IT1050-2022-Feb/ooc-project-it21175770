#include<iostream>
#include<cstring>
#include "Land.h"
#include "Architect.h"
using namespace std;

Land :: Land()
{
  
}

void Land :: add_land_details(string L_name , string L_location , int L_no , string L_size)
{
  l_name = L_name;
  l_location = L_location;
  l_land_no = L_no;
  l_size = L_size;
  
}

void Land :: display_details ()
{
  cout<<"L_name:"<<l_name<<endl;
  cout<<"L_location:"<<l_location<<endl;
  cout<<"L_no:"<<l_land_no<<endl;
  cout<<"L_size:"<<l_size<<endl;

}

void Land :: land_area()
{
  
}
