#define size 10
#include<iostream>
using namespace std;
class Land
{
private:
string l_name;
string l_location;
Architect * architect[size];
int l_land_no;
string l_size;

public:
Land();
void add_land_details(string L_name , string L_location , int l_land_no , string L_size);
void display_details ();
void land_area();
};
