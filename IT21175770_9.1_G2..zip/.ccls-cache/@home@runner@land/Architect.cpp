#include<iostream>
#include "Architect.h"
#include "Land.h"
using namespace std;

Architect :: Architect()
{
  
}

void Architect :: Architect_details(string a_name , int a_no , string a_email , string a_address)
{
  Architect_name = a_name;
  Architect_no = a_no;
  Architect_email = a_email;
  Architect_address  = a_address; 
  
}

void Architect :: visit_the_land_details()
{
  
}

void Architect :: display_Arc_details()
{
  cout<<"a_name:"<<Architect_name<<endl;
  cout<<"a_no:"<<Architect_no<<endl;
  cout<<"a_email:"<<Architect_email<<endl;
  cout<<"a_address:"<<Architect_address<<endl;
}

void Architect :: draw_plan()
{
  
}