#include<iostream>
#include "Land.h"
#include "Architect.h"
using namespace std;

int main()
{
  Land land1;
  Land land2;

  Architect Arch1;
  Architect Arch2;

  land1.add_land_details("A01 Land" ,"malabe-02" , 01 , "10.0 perches");

  land2.add_land_details("A02 Land" , "borella" , 03 , "12.0 perches");

  Arch1.Architect_details("kamal" , 03 , "kamal03@gmail.com" , "rajagiriya");

  Arch2.Architect_details("vimal" , 05 , "vimal05@gmail.com" ,"koswatha");

  return 0;
}