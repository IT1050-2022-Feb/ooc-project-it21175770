#include<iostream>
using namespace std;
class Architect
{
private:
string Architect_name;
int Architect_no;
Land * land;
string Architect_email;
string Architect_address;

public:
Architect();
void Architect_details(string a_name , int a_no , string a_email , string a_address);
void visit_the_land_details();
void display_Arc_details();
void draw_plan();

};